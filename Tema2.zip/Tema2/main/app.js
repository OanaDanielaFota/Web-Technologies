function addTokens(input, tokens){
    if(typeof input !=="string") {
        throw new Error("Invalid input");
    }

    if(input.length < 6) {
        throw new Error("Input should have at least 6 characters");
    }

    if(Array.isArray(tokens)) {
        tokens.forEach((e) => {
            if(typeof e.tokenName != "string") {
                throw new Error("Invalid array format");
            }
        });
    }

    if(!(input.includes("..."))) {
        return input;
    }
    else {
        var x;
        tokens.forEach((e) =>
               x = input.replace("...", "${" + e.tokenName + "}")
        );
        return x;
    }
}

const app = {
    addTokens: addTokens
}

module.exports = app;